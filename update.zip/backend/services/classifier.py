"""分类引擎 / 识别编排服务（规格书第八节架构：分类引擎 → 字段提取 → 置信度计算）。

把完整识别链路串起来：
  解析 → (OCR) → 文本清洗 → 规则引擎 → 字段提取 → AI 兜底 → 综合置信度 → 建议分类+文件名

规则优先，AI 只兜底；不确定的结果（review/reject）交由人工审核。
业务代码（批量整理 / 人工审核 / 预览）统一调用本服务。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from sqlalchemy.orm import Session

from backend.config import settings
from backend.models import Category, RecognitionTemplate, RenameTemplate
from backend.services.ai_service import ai_service
from backend.services.confidence_service import (
    DECISION_AUTO,
    DECISION_REJECT,
    DECISION_REVIEW,
    ConfidenceResult,
    confidence_service,
)
from backend.services.field_extractor import SOURCE_FILENAME, field_extractor
from backend.services.filename_rule_service import filename_rule_service
from backend.services.ocr_cleaner import get_known_companies, ocr_cleaner
from backend.services.ocr_service import ocr_service
from backend.services.parser_service import parser_service
from backend.services.rename_service import DEFAULT_TEMPLATE, rename_service
from backend.services.rule_engine import (
    RuleEngine,
    RuleMatch,
    rule_confidence,
)
from backend.services.sample_service import sample_service
from backend.services.text_service import clean_parsed_document
from backend.utils.logger import get_logger

logger = get_logger("services.classifier")


@dataclass
class AnalysisResult:
    """一次完整识别的结果（供归档/预览/人工审核使用）。"""
    file_path: str
    text: str = ""
    document_type: str = ""
    title: str = ""
    fields: dict = field(default_factory=dict)          # 字段名 -> (值, 置信度, 来源)
    field_values: dict = field(default_factory=dict)   # 字段名 -> 值（纯值，供重命名）
    rule_matches: list = field(default_factory=list)
    ai_result: dict | None = None
    field_conflicts: list = field(default_factory=list)  # 字段冲突记录
    confidence: object | None = None                    # ConfidenceResult
    decision: str = ""
    suggested_category: str = ""                        # 分类 path
    suggested_filename: str = ""
    needs_ocr: bool = False
    excel_match: dict | None = None
    error: str = ""

    def to_dict(self) -> dict:
        conf = self.confidence.to_dict() if self.confidence else None
        return {
            "file_path": self.file_path,
            "text": self.text[:2000],
            "document_type": self.document_type,
            "title": self.title,
            "fields": self.field_values,
            "field_conflicts": self.field_conflicts,
            "decision": self.decision,
            "confidence": conf,
            "suggested_category": self.suggested_category,
            "suggested_filename": self.suggested_filename,
            "needs_ocr": self.needs_ocr,
            "excel_match": self.excel_match,
            "error": self.error,
        }


class ClassifierService:
    """识别编排：解析 + OCR + 规则 + 字段 + AI + 置信度。"""

    def __init__(self, db: Session):
        self.db = db
        self.rule_engine = RuleEngine(db)

    # ---------- 主入口 ----------
    def analyze(self, file_path: str | Path, document_id: int | None = None) -> AnalysisResult:
        path = Path(file_path)
        result = AnalysisResult(file_path=str(path))

        # 0. 文件名规则优先：命中直接归档，不解析内容（省 token 快速通道）
        fn_match = filename_rule_service.match(path.name, self.db)
        if fn_match:
            result.document_type = fn_match.category_name
            result.title = path.stem
            result.suggested_category = fn_match.category_path
            result.suggested_filename = path.name  # 保持原名归档
            result.confidence = ConfidenceResult(
                score=0.99, decision=DECISION_AUTO, components={"filename": 1.0}
            )
            result.decision = DECISION_AUTO
            # 文件名级字段兜底（零解析成本）：合同号 / 日期 / 船名 / 物料。
            # 扫描件合同 PDF 没有文本层，缺了这一步会导致合同号为空、
            # 对账时归不到业务线（MISSING_DOC 误报）。
            for f in field_extractor.extract_filename_only(path.name):
                result.fields[f.name] = (f.value, f.confidence, f.source or SOURCE_FILENAME)
                result.field_values[f.name] = f.value
            result.field_conflicts = [c.__dict__ for c in field_extractor.last_conflicts]
            logger.info("文件名规则命中 %s -> %s（直接归档）", path.name, fn_match.category_path)
            return result

        try:
            # 1. 解析
            parsed = parser_service.parse_file(path)
            parsed = clean_parsed_document(parsed)

            # 2. OCR 补充（扫描 PDF / 图片）+ OCR 结果二次清洗
            known_companies: list[str] = get_known_companies(self.db)
            if parsed.needs_ocr:
                result.needs_ocr = True
                parsed.text = self._ocr_text(path, parsed)
                cleaned = ocr_cleaner.clean(parsed.text, known_companies=known_companies)
                parsed.text = cleaned.text

            text = parsed.text or ""
            pre_kie: dict[str, str] = {}
            if not text and settings.OCR_KIE_ENABLED and parsed.needs_ocr:
                # RapidOCR 一个字都没认出来：先用视觉 KIE 抢救，把字段拼成文本让规则继续工作
                try:
                    from backend.services.ocr_kie_service import CORE_FIELDS, ocr_kie_service

                    kie = ocr_kie_service.extract_from_file(path)
                    if kie.ok:
                        pre_kie = dict(kie.fields)
                        text = "\n".join(f"{k} | {v}" for k, v in pre_kie.items())
                        logger.info(
                            "RapidOCR 无文本，KIE 抢救出 %d 个字段: %s",
                            len(pre_kie), sorted(pre_kie),
                        )
                except Exception as e:  # noqa: BLE001
                    logger.warning("KIE 抢救异常（已跳过，不影响识别）: %s", e)
            result.text = text
            if not text:
                result.error = "未提取到任何文本内容"
                result.decision = DECISION_REJECT
                return result

            # 3. 规则引擎（优先）
            matches = self.rule_engine.evaluate(text)
            result.rule_matches = [m.__dict__ for m in matches]
            best: RuleMatch | None = matches[0] if matches else None
            rule_conf = rule_confidence(best) if best else 0.0

            # 4. 字段提取（多规则并行引擎：正则+关键词+模板+文件名补全）
            extracted = field_extractor.extract(text, filename=path.name, known_companies=known_companies)
            result.field_conflicts = [c.__dict__ for c in field_extractor.last_conflicts]
            fields_dict: dict[str, tuple] = {}
            for f in extracted:
                fields_dict[f.name] = (f.value, f.confidence, f.source or "RULE")
            result.fields = fields_dict
            result.field_values = {k: v[0] for k, v in fields_dict.items()}
            field_conf = (
                sum(f[1] for f in fields_dict.values()) / len(fields_dict)
                if fields_dict
                else 0.0
            )

            # KIE 抢救出来的字段并入结果（只取核心字段，数量/摘要类实测易错位）
            if pre_kie:
                self._merge_kie_fields(result, pre_kie, list(CORE_FIELDS))
                if result.fields:
                    field_conf = sum(v[1] for v in result.fields.values()) / len(result.fields)

            # 4.3 Excel 登记表权威数据源匹配（纯本地零 token）：
            # OCR 提取合同号（或日期+船名 / 物料+数量）命中 Excel 台账行，
            # 命中则用 Excel 行字段覆盖 OCR 结果，命名 / 归档更准。
            from backend.services.excel_matcher import excel_matcher

            try:
                em = excel_matcher.match(self.db, result.field_values)
            except Exception as e:  # noqa: BLE001
                logger.warning("Excel 登记表匹配异常（已跳过，不影响识别）: %s", e)
                em = None
            if em and em.matched:
                # 台账的金额/数量口径是「合同口径」（合同金额、合同数量），
                # 而结算单/发票/回单上的金额是单据自身金额（结算金额、票面
                # 价税合计、实付金额），两者不是一回事。用台账行覆盖会把
                # 结算单金额写成合同金额（7990500 vs 结算 7922962.05），
                # 导致对账金额勾稽全错 —— 所以只对合同类单据允许覆盖。
                name_upper = path.name.upper()
                is_contract = (
                    "合同" in path.name
                    or "协议" in path.name
                    or name_upper.startswith(
                        ("HSYCCG", "HSYCXS", "SJWLCG", "SJWLXS", "BOTC", "SOTC")
                    )
                )
                ledger_only = set() if is_contract else {"amount", "quantity"}
                for k, v in em.fields.items():
                    if k in ledger_only and result.field_values.get(k):
                        continue
                    result.field_values[k] = v
                    result.fields[k] = (v, 1.0, "EXCEL")
                result.excel_match = em.to_dict()
                logger.info(
                    "Excel 登记表命中 %s/%s（%s），已用台账字段覆盖 OCR",
                    em.source_name, em.sheet_name, em.key,
                )

            # 4.4 视觉 KIE 兜底（本地 Xiaomi-OCR-0）：扫描件/图片缺关键字段，或字段
            # 平均置信度偏低时，让视觉模型直读原图补字段。CPU 单页约 50s，只在触发
            # 条件下执行；失败静默跳过，绝不中断整理主流程。
            if settings.OCR_KIE_ENABLED and parsed.needs_ocr and not pre_kie:
                trigger = self._kie_trigger_fields(best, result.field_values, field_conf)
                if trigger:
                    try:
                        from backend.services.ocr_kie_service import ocr_kie_service

                        kie = ocr_kie_service.extract_from_file(path)
                        if kie.ok:
                            self._merge_kie_fields(result, kie.fields, trigger)
                            logger.info(
                                "KIE 兜底补字段 %s：%s（%.1fs）",
                                path.name, sorted(kie.fields.keys()), kie.elapsed,
                            )
                            # 补字段后重算字段均分，供综合置信度使用
                            if result.fields:
                                field_conf = sum(
                                    v[1] for v in result.fields.values()
                                ) / len(result.fields)
                    except Exception as e:  # noqa: BLE001
                        logger.warning("KIE 兜底异常（已跳过，不影响识别）: %s", e)

            # 4.6 格式样本匹配（人工样例学习，纯本地零 token）：
            # 用户上传的清晰样本指纹与文档版式一致 -> 直接自动归档，跳过 AI
            sample, sample_score = sample_service.match_all(
                self.db, text, list(fields_dict.keys())
            )
            if sample is not None:
                # 规则优先：规则引擎已强命中（>=2 个关键词）且与样本类型冲突时，
                # 信任规则。销售/采购合同版式高度相似，样本指纹易误判相似版式。
                rule_strong = (
                    best is not None
                    and bool(getattr(best, "matched_keywords", None))
                    and len(best.matched_keywords) >= 2
                )
                if rule_strong and best.category_name != sample.document_type:
                    logger.info(
                        "格式样本 #%s 判定 %s 与规则 %s 冲突，信任规则（命中 %d 个关键词: %s）",
                        sample.id, sample.document_type, best.category_name,
                        len(best.matched_keywords), best.matched_keywords,
                    )
                else:
                    result.document_type = sample.document_type
                    result.suggested_category = sample.category_path
                    result.confidence = ConfidenceResult(
                        score=round(sample_score, 3),
                        decision=DECISION_AUTO,
                        components={"sample": sample_score},
                    )
                    result.decision = DECISION_AUTO
                    render_fields = dict(result.field_values)
                    if result.document_type and "document_type" not in render_fields:
                        render_fields["document_type"] = result.document_type
                    template = self._category_template(sample.category_path)
                    result.suggested_filename = rename_service.render(
                        template, render_fields, Path(result.file_path).suffix
                    )
                    sample.usage_count += 1
                    self.db.commit()
                    logger.info(
                        "格式样本命中 #%s %s -> %s (score=%.3f)",
                        sample.id, path.name, sample.category_path, sample_score,
                    )
                    return result

            # 4.5 识别模板匹配（同类文件"记性"）：命中且关键字段齐全 -> 直接自动归档，跳过 AI
            tpl = self._match_template(best.category_name if best else None, fields_dict)
            if tpl is not None:
                result.document_type = best.category_name or tpl.document_type
                result.suggested_category = tpl.category_path
                result.confidence = ConfidenceResult(
                    score=0.96, decision=DECISION_AUTO, components={"template": 1.0}
                )
                result.decision = DECISION_AUTO
                render_fields = dict(result.field_values)
                if result.document_type and "document_type" not in render_fields:
                    render_fields["document_type"] = result.document_type
                template = self._category_template(tpl.category_path)
                result.suggested_filename = rename_service.render(
                    template, render_fields, Path(result.file_path).suffix
                )
                tpl.usage_count += 1
                self.db.commit()
                logger.info(
                    "识别模板命中 %s -> %s（自动归档，跳过 AI）",
                    path.name, tpl.category_path,
                )
                return result

            # 5. AI 兜底（可选）
            ai_conf = None
            ai_result = None
            candidate_types = self._candidate_types(best)
            ai_needed = settings.AI_ENABLED and (
                best is None or rule_conf < settings.AUTO_ARCHIVE_THRESHOLD
            )
            if ai_needed:
                ai_result = ai_service.classify_document(
                    text,
                    context={
                        "candidate_types": candidate_types,
                        "known_fields": result.field_values,
                        "rule_result": best.category_name if best else "无",
                    },
                )
                if ai_result:
                    # AI 置信度过低（如 OCR 模型返回 0.0）视为不可用，
                    # 避免拉低综合置信度、也不让低质结果覆盖规则。
                    ai_conf_raw = float(ai_result.get("confidence") or 0.0)
                    if ai_conf_raw >= 0.5:
                        ai_conf = ai_conf_raw
                    else:
                        ai_result = None

            # 6. 综合置信度
            keyword_conf = self._keyword_conf(best)
            conf = confidence_service.calculate(
                rule_conf=rule_conf,
                field_conf=field_conf,
                keyword_conf=keyword_conf,
                ai_conf=ai_conf,
            )
            result.confidence = conf
            result.decision = conf.decision

            # 7. 建议分类 + 文档类型
            self._set_suggestion(result, best, ai_result, text)

            logger.info(
                "识别完成 %s: 类型=%s 置信度=%.3f 决策=%s",
                path.name,
                result.document_type,
                conf.score,
                conf.decision,
            )
            return result
        except Exception as e:  # noqa: BLE001
            logger.error("识别失败 %s: %s", path, e)
            result.error = str(e)
            result.decision = DECISION_REJECT
            return result

    # ---------- 内部方法 ----------
    def _ocr_text(self, path: Path, parsed) -> str:
        """对需 OCR 的文件执行 OCR，返回拼接文本。"""
        file_type = parsed.metadata.get("file_type", "")
        if file_type == "pdf":
            pages = ocr_service.recognize_pdf(path)
            return "\n".join(p.text for p in pages if p.text)
        # 图片
        res = ocr_service.recognize_image_file(path)
        return res.text

    def _kie_trigger_fields(self, best: RuleMatch | None, values: dict, field_conf: float) -> list[str]:
        """判断是否需要视觉 KIE 兜底，返回要抽取的字段清单（空列表=不触发）。

        触发条件（满足其一）：
        1. 该单据类型的必需字段缺失（优先用识别模板的 require_fields，没模板则看金额）；
        2. 字段平均置信度低于审核阈值（说明整条正则链路不可靠）。
        """
        required = ["amount"]
        doc_type = best.category_name if best else None
        if doc_type:
            tpl = (
                self.db.query(RecognitionTemplate)
                .filter(
                    RecognitionTemplate.document_type == doc_type,
                    RecognitionTemplate.enabled.is_(True),
                )
                .first()
            )
            if tpl and tpl.require_fields_list:
                required = list(tpl.require_fields_list)
        missing = [f for f in required if not str(values.get(f) or "").strip()]
        low_conf = field_conf < settings.REVIEW_THRESHOLD
        if not missing and not low_conf:
            return []
        wanted: set[str] = set(missing)
        if low_conf:
            wanted |= {"amount", "contract_no", "invoice_no", "date", "company"}
        return sorted(wanted)

    def _merge_kie_fields(self, result: AnalysisResult, fields: dict, wanted: list[str]) -> None:
        """把 KIE 字段并入识别结果：缺失补上，高价值字段冲突时以视觉直读为准。"""
        import re

        overwrite = {"amount", "contract_no", "invoice_no"}

        def _same(a: str, b: str) -> bool:
            """忽略空格/大小写视为同值（模型常丢合同号里的空格）。"""
            return re.sub(r"\s+", "", a).upper() == re.sub(r"\s+", "", b).upper()

        conf = settings.OCR_KIE_CONF
        for k, v in fields.items():
            if not v or (wanted and k not in wanted):
                continue
            old = str(result.field_values.get(k) or "").strip()
            if old and old != v:
                if _same(old, v):
                    continue
                if k in overwrite:
                    result.field_conflicts.append({
                        "field": k,
                        "values": [old, v],
                        "chosen": v,
                        "reason": "视觉 KIE 直读值覆盖正则结果",
                    })
                    result.field_values[k] = v
                    result.fields[k] = (v, conf, "KIE")
                else:
                    result.field_conflicts.append({
                        "field": k,
                        "values": [old, v],
                        "chosen": old,
                        "reason": "保留既有值，KIE 仅记录冲突",
                    })
                continue
            if old:
                continue
            result.field_values[k] = v
            result.fields[k] = (v, conf, "KIE")

    def _match_template(self, doc_type: str | None, fields: dict) -> "RecognitionTemplate | None":
        """识别模板匹配：同类型且关键字段齐全即命中。"""
        if not doc_type or doc_type in ("其他", "未识别"):
            return None
        tpl = (
            self.db.query(RecognitionTemplate)
            .filter(
                RecognitionTemplate.document_type == doc_type,
                RecognitionTemplate.enabled.is_(True),
            )
            .first()
        )
        if tpl is None:
            return None
        require = tpl.require_fields_list
        if not require:
            return None
        if all(fields.get(k) for k in require):
            return tpl
        return None

    def _candidate_types(self, best: RuleMatch | None) -> list[str]:
        """生成 AI 候选文档类型列表。"""
        names = []
        for c in (
            self.db.query(Category)
            .filter(Category.enabled.is_(True))
            .order_by(Category.sort_order)
            .all()
        ):
            names.append(c.name)
        if best and best.category_name not in names:
            names.insert(0, best.category_name)
        return names or ["其他"]

    def _keyword_conf(self, best: RuleMatch | None) -> float | None:
        """关键词置信度：命中关键词数量归一化。"""
        if best is None or not best.matched_keywords:
            return 0.0
        return min(1.0, len(best.matched_keywords) / 5.0)

    def _set_suggestion(
        self,
        result: AnalysisResult,
        best: RuleMatch | None,
        ai_result: dict | None,
        text: str,
    ) -> None:
        """确定建议分类与文件名。"""
        # 文档类型：AI 高置信才可覆盖规则；否则以规则命中为准
        doc_type = ""
        if ai_result and ai_result.get("document_type"):
            ai_type = str(ai_result["document_type"]).strip()
            ai_conf = float(ai_result.get("confidence") or 0.0)
            if best and best.category_name:
                # 规则已有明确命中：仅当 AI 高置信且非"其他"时采用 AI，否则信任规则
                if ai_conf >= 0.7 and ai_type and ai_type != "其他":
                    doc_type = ai_type
                else:
                    doc_type = best.category_name
            elif ai_type and ai_type != "其他":
                doc_type = ai_type
        if not doc_type and best:
            doc_type = best.category_name
        result.document_type = doc_type or "其他"

        # 建议分类 path：规则命中优先，否则尝试按 AI 类型匹配分类
        category_path = best.category_path if best else ""
        if not category_path and doc_type:
            category = (
                self.db.query(Category)
                .filter(Category.name == doc_type, Category.enabled.is_(True))
                .first()
            )
            if category:
                category_path = category.path
        result.suggested_category = category_path or "其他"

        # 标题
        title = ""
        if ai_result and ai_result.get("title"):
            title = str(ai_result["title"])
        result.title = title or doc_type

        # 建议文件名：分类模板 或 默认模板
        # 把文档类型注入字段，避免文件名中"类型"位置变成"未识别"
        render_fields = dict(result.field_values)
        if doc_type and "document_type" not in render_fields:
            render_fields["document_type"] = doc_type
        template = self._category_template(category_path) if category_path else DEFAULT_TEMPLATE
        result.suggested_filename = rename_service.render(
            template, render_fields, Path(result.file_path).suffix
        )

    def _category_template(self, category_path: str) -> str:
        category = (
            self.db.query(Category)
            .filter(Category.path == category_path)
            .first()
        )
        if category:
            tpl = (
                self.db.query(RenameTemplate)
                .filter(RenameTemplate.category_id == category.id, RenameTemplate.enabled.is_(True))
                .first()
            )
            if tpl:
                return tpl.template
        return DEFAULT_TEMPLATE
