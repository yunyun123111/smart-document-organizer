"""系统设置 Pydantic 模型。"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel


class SettingsOut(BaseModel):
    """可查看/修改的系统设置（不含敏感 key 明文展示时的 API Key）。"""
    document_root: str
    inbox_root: str
    ocr_enabled: bool
    ocr_provider: str
    ocr_base_url: str
    ocr_model: str
    ocr_timeout: int
    ocr_kie_enabled: bool
    ocr_fallback: bool
    ai_enabled: bool
    ai_provider: str
    ai_base_url: str
    ai_model: str
    ai_api_key_set: bool  # 是否已配置
    ai_timeout: int
    ai_max_retries: int
    ai_max_text_length: int
    auto_archive_threshold: float
    review_threshold: float
    conf_rule_weight: float
    conf_field_weight: float
    conf_keyword_weight: float
    conf_ai_weight: float
    allow_overwrite: bool
    # 局域网访问
    host_bind: str
    access_password_set: bool
    # 邮箱接收
    email_enabled: bool
    email_imap_host: str
    email_imap_port: int
    email_user: str
    email_password_set: bool
    email_poll_interval: int
    # 归档目录结构模板（category/year/month 等）
    archive_template: str
    # 目录自动监控
    watch_enabled: bool
    watch_dirs: list  # 监控目录列表（绝对路径）
    watch_interval: int
    # 盖章检测
    seal_detect_enabled: bool


class SettingsUpdate(BaseModel):
    """允许更新的设置字段（均可选）。"""
    document_root: Optional[str] = None
    inbox_root: Optional[str] = None
    ocr_enabled: Optional[bool] = None
    ocr_provider: Optional[str] = None
    ocr_base_url: Optional[str] = None
    ocr_model: Optional[str] = None
    ocr_timeout: Optional[int] = None
    ocr_kie_enabled: Optional[bool] = None
    ocr_fallback: Optional[bool] = None
    ai_enabled: Optional[bool] = None
    ai_provider: Optional[str] = None
    ai_base_url: Optional[str] = None
    ai_api_key: Optional[str] = None
    ai_model: Optional[str] = None
    ai_timeout: Optional[int] = None
    ai_max_retries: Optional[int] = None
    ai_max_text_length: Optional[int] = None
    auto_archive_threshold: Optional[float] = None
    review_threshold: Optional[float] = None
    conf_rule_weight: Optional[float] = None
    conf_field_weight: Optional[float] = None
    conf_keyword_weight: Optional[float] = None
    conf_ai_weight: Optional[float] = None
    allow_overwrite: Optional[bool] = None
    # 局域网访问
    host_bind: Optional[str] = None
    access_password: Optional[str] = None
    # 邮箱接收
    email_enabled: Optional[bool] = None
    email_imap_host: Optional[str] = None
    email_imap_port: Optional[int] = None
    email_user: Optional[str] = None
    email_password: Optional[str] = None
    email_poll_interval: Optional[int] = None
    archive_template: Optional[str] = None
    # 目录自动监控
    watch_enabled: Optional[bool] = None
    watch_dirs: Optional[list] = None  # 监控目录列表
    watch_interval: Optional[int] = None
    # 盖章检测
    seal_detect_enabled: Optional[bool] = None
